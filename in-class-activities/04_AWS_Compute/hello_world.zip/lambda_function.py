def lambda_handler(event, context):
    # test: {'key1': 1, 'key2': 2}
    total = event['key1'] + event['key2']
    return total