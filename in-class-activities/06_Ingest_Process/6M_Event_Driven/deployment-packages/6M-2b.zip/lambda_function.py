import boto3
import json

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    '''
    transform_2 (Subtract 1 from decibels and write new attribute in DynamoDB)
    for functional decomp demo
    '''
    source = None
    if 'Records' in event:
        if 'Sns' in event['Records'][0]:
            # If data coming from SNS, grab Message data
            # Also get TopicArn for Demo purposes
            source = event['Records'][0]['Sns']['TopicArn']
            event = json.loads(event['Records'][0]['Sns']['Message'])
        else:
            # If data being pulled from SQS queue, need to grab "body"
            # of message form SQS output
            # For demo, also collect eventSourceARN
            source = event['Records'][0]['eventSourceARN']
            event = json.loads(event['Records'][0]['body'])

    # enter data into a DB
    # 'id' is concatenation of location/sensor/timestamp for sake of demo
    # in real DB, 'timestamp' + transform num. could be good sorting keys
    table = dynamodb.Table('6M_DB')
    table.put_item(
       Item={
         'id': 't2_' + event['location'] + event['sensor'] + event['timestamp'],
         'transform_2': int(event['db']) - 1
            }
    )

    return {'StatusCode': 200}
