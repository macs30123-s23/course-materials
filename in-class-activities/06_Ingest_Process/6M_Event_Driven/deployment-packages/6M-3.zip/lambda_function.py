import boto3
import json
import base64

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    source = None
    if 'Records' in event:
        # Assume Kinesis Data is coming in
        # Kinesis data is base64 encoded so need to decode first
        source = event['Records'][0]['eventSourceARN']
        decoded = base64.b64decode(event['Records'][0]['kinesis']['data'])
        event = json.loads(decoded)

    # enter data into a DB
    # 'id' is concatenation of location/sensor/timestamp for sake of demo 
    # + 's_' for streaming
    # in real DB, 'timestamp' would be a good sorting key
    table = dynamodb.Table('6M_DB')
    table.put_item(
       Item={
            'id': 's_' + event['location'] + event['sensor'] + event['timestamp'],
            'db': event['db'],
            'source': source
        }
    )

    return {'StatusCode': 200}